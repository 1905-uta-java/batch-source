
import java.util.List;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.revature.dao.CheckingsDao;
import com.revature.dao.CheckingsDaoImpl;
import com.revature.dao.PasswordsDao;
import com.revature.dao.PasswordsDaoImpl;
import com.revature.dao.UsersDao;
import com.revature.dao.UsersDaoImpl;
import com.revature.model.*;

import com.revature.util.ConnectionUtil;

public class Driver {

	public static void main(String[] args) {

		UsersDao ud = new UsersDaoImpl();
		PasswordsDao pd = new PasswordsDaoImpl();
		CheckingsDao cd = new CheckingsDaoImpl();

		// Users u = new Users( "Freeks", "Jin", "aroff4", "04 Superior Street",
		// "Pennsylvania", "Philadelphia", "19172", "215-154-2206", "aroff4@diigo.com");
		// ud.createUser(u);
		List<Users> users = ud.getUsers();
		List<Passwords> pass = pd.getPasswords();
		List<Checkings> check = cd.getCheckingAccounts();
		/*
		 * int holder = 0; for (Users k : users) { System.out.println(k); if
		 * (k.getUsername().equals("aroff4")) { holder = k.getId(); } }
		 * System.out.println(holder);
		 * 
		 * for (Users k : users) { System.out.println(k.getFirstName() + " " +
		 * k.getLastName()); }
		 * 
		 * Passwords p = new Passwords(holder, "Benlee"); //pd.createPassword(p);
		 * 
		 * 
		 * 
		 * for (Passwords pp : pass) { System.out.println(pp);
		 * 
		 * }
		 * 
		 * Checkings c = new Checkings(holder); cd.createChecking(c); c =new
		 * Checkings(holder, 20000); cd.updateChecking(c);
		 * 
		 * 
		 * for (Checkings ch : check) { System.out.println(ch);
		 * 
		 * }
		 */

		/*
		 * try { Connection c = ConnectionUtil.getHardCodedConnection();
		 * System.out.println(c.getMetaData().getDriverName()); }
		 * 
		 * catch (SQLException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */

		Scanner kbd = new Scanner(System.in);

		int x = 1;
		while (x == 1) {

			int userChoice = Helper.menu();

			if (userChoice == 1) {
				int run = 0;
				int run2 = 0;
				while (run == 0) {
					while (run == 0) {
						System.out.println("Enter username or email address ");
						System.out.println("To exit, type STOP ");
						String userLogin = kbd.next();
						userLogin = userLogin.toLowerCase();
						if (userLogin.equals("stop")) {
							run = 2;
							break;
						}
						System.out.println("Enter password ");
						String passLogin = kbd.next();

						Users uCurrent = new Users();
						Passwords pCurrent = new Passwords();
						Checkings cCurrent = new Checkings();

						int holder = 0;
						boolean pass1 = false;
						for (Users k : users) {

							if (k.getUsername().equals(userLogin) || k.getEmail().equals(userLogin)) {
								uCurrent = k;
								pass1 = true;
							}
						}
						if (!pass1) {
							System.out.println("Incorrect credentials. Try  again");
							continue;
						}
						boolean pass2 = false;

						for (Passwords k : pass) {

							if (uCurrent.getId() == k.getUserID()) {
								pCurrent = k;

							}
						}
						if (passLogin.equals(pCurrent.getPassword())) {

							for (Checkings k : check) {

								if (uCurrent.getId() == k.getUserID()) {
									cCurrent = k;

								}
							}
							while (run == 0) {
								System.out.println(cCurrent.toString() + "\n");

								System.out.println("1 - Deposit");
								System.out.println("2 - Withdraw");
								System.out.println("3 - Log out\n");
								int tChoice = kbd.nextInt();

								if (tChoice == 1) {
									System.out.println("Enter deposit amount in XX.XX forat: ");
									double deposit = kbd.nextDouble();
									double currVal = cCurrent.getCurrBalance();
									cCurrent = new Checkings(uCurrent.getId(), currVal + deposit);
									cd.updateChecking(cCurrent);
									check = cd.getCheckingAccounts();
									System.out.println("You deposited $" + deposit +"\n");

									for (Checkings k : check) {

										if (uCurrent.getId() == k.getUserID()) {
											cCurrent = k;

										}
									}
									

								}
								if (tChoice == 2) {
									System.out.println("Enter withdrawal amount in XX.XX forat: ");
									double withdraw = kbd.nextDouble();
									double currVal = cCurrent.getCurrBalance();
									if (currVal - withdraw >= 0) {
										cCurrent = new Checkings(uCurrent.getId(), currVal - withdraw);
										cd.updateChecking(cCurrent);
										check = cd.getCheckingAccounts();
										for (Checkings k : check) {

											if (uCurrent.getId() == k.getUserID()) {
												cCurrent = k;

											}
										}
										System.out.println("You withdrew $" + "\n");
									} else {
										System.out.println("Not enough funds!\n");
									}

								}
								if (tChoice == 3) {
									System.out.println("Logging out");
									run = 2;
									break;
								}
							}

						}
						System.out.println("Incorrect credentials\n");
					}
				}
			}
			if (userChoice == 2) {

				String newUser;
				String newPass;
				String newFirstName;
				String newLastName;
				String newAddress;
				String newState;
				String newCity;
				String newZip;
				String newPhone;
				String newEmail;

				System.out.println("Creating New User \n");
				// Check username availability

				while (true) {

					System.out.println("Enter a username ");
					System.out.println("\nUsername must contain:\n");
					System.out.println("\t-6-16 characters\n");
					newUser = kbd.next();
					newUser = newUser.toLowerCase();
					if (newUser.length() < 6) {
						System.out.println("Username is too short\n");
						continue;
					}
					if (newUser.length() > 16) {
						System.out.println("Username is too long\n");
						continue;
					}

					if (!noIllegalChar(newUser)) {
						System.out.println("Username contained illegal chararacter(s). \n");
						continue;
					}
					if (isAvailable(newUser)) {
						break;
					} else {
						System.out.println(newUser + " is unavailable. \n");
					}

				}
				while (true) {

					System.out.println("Enter a password ");
					System.out.println("\nPasswords must contain:\n");
					System.out.println("\t-8-15 characters\n");
					System.out.println("\t-a minimum of 1 lower case letter [a-z]\n");
					System.out.println("\t-a minimum of 1 upper case letter [A-Z]\n");
					System.out.println("\t-a minimum of 1 numeric character [0-9]\n");

					newPass = kbd.next();

					if (newPass.length() < 8) {
						System.out.println("Username is too short\n");
						continue;
					}
					if (newPass.length() > 15) {
						System.out.println("Username is too long\n");
						continue;
					}
					if (!noIllegalChar2(newPass)) {
						System.out.println("Password contained illegal character.\n");
						continue;
					}

					if (isValidPass(newPass)) {
						break;
					}

					else {
						System.out.println("Password not valid. Please follow constraints \n");
					}
				}
				while (true) {

					System.out.println("First name: ");
					newFirstName = kbd.next();

					if (newFirstName.equals("")) {
						System.out.println("Please enter a valid input.");
						continue;
					} else
						break;
				}

				while (true) {

					System.out.println("Last name: ");
					newLastName = kbd.next();

					if (newLastName.equals("")) {
						System.out.println("Please enter a valid input.");
						continue;
					} else
						break;
				}

				while (true) {

					System.out.println("Address: ");
					newAddress = kbd.next();

					if (newAddress.equals("")) {
						System.out.println("Please enter a valid input.");
						continue;
					} else
						break;
				}

				while (true) {

					System.out.println("State: ");
					newState = kbd.next();

					if (newState.equals("")) {
						System.out.println("Please enter a valid input.");
						continue;
					} else
						break;
				}

				while (true) {

					System.out.println("City: ");
					newCity = kbd.next();

					if (newCity.equals("")) {
						System.out.println("Please enter a valid input.");
						continue;
					} else
						break;
				}

				while (true) {

					System.out.println("Zip code: ");
					newZip = kbd.next();

					if (newZip.equals("")) {
						System.out.println("Please enter a valid input.");
						continue;
					} else
						break;
				}

				while (true) {

					System.out.println("Phone number: ");
					newPhone = kbd.next();

					if (newPhone.equals("")) {
						System.out.println("Please enter a valid input.");
						continue;
					} else
						break;
				}

				while (true) {

					System.out.println("Email: ");
					newEmail = kbd.next();
					newEmail = newEmail.toLowerCase();

					if (newEmail.equals("")) {
						System.out.println("Please enter a valid input.");
						continue;
					}
					if (validEmail(newEmail))
						break;
					else {
						System.out.println("Not a valid email");
						continue;
					}
				}
				// Creating new user
				System.out.println("User successfully created.\n");
				Users newAccount = new Users(newLastName, newFirstName, newUser, newAddress, newState, newCity, newZip,
						newPhone, newEmail);
				ud.createUser(newAccount);
				users = ud.getUsers();

				int holder = 0;
				for (Users k : users) {
					if (k.getUsername().equals(newUser)) {
						holder = k.getId();

					}
					Passwords np = new Passwords(holder, newPass);
					Checkings nc = new Checkings(holder, holder + 10000);

					pd.createPassword(np); // Creates password data
					cd.createChecking(nc); // Creates checking account

					pass = pd.getPasswords();
					check = cd.getCheckingAccounts();

				}
				if (userChoice != 1 || userChoice != 2) {
					continue;
				}
			}
		}
	}

	public static boolean noIllegalChar(String s) {

		boolean valid = true;

		char[] a = s.toCharArray();

		for (char c : a) {
			valid = ((c >= 'a') && (c <= 'z')) || ((c >= 'A') && (c <= 'Z')) || ((c >= '0') && (c <= '9')) || (c == '.')
					|| (c == '-');

			if (!valid) {
				break;
			}
		}

		return valid;
	}

	// Password check
	public static boolean noIllegalChar2(String s) {

		boolean valid = true;

		char[] a = s.toCharArray();

		for (char c : a) {
			valid = ((c >= 'a') && (c <= 'z')) || ((c >= 'A') && (c <= 'Z')) || ((c >= '0') && (c <= '9')) || (c == '.')
					|| (c == '-');

			if (!valid) {
				break;
			}
		}

		return valid;
	}

	public static boolean isValidPass(String s) {

		boolean valid = false;
		boolean hasLower = false;
		boolean hasUpper = false;
		boolean hasDigit = false;

		char[] a = s.toCharArray();

		for (char c : a) {
			if ((c >= 'a') && (c <= 'z')) {
				hasLower = true;
			}
			if ((c >= 'A') && (c <= 'Z')) {
				hasUpper = true;
			}
			if ((c >= '0') && (c <= '9')) {
				hasDigit = true;
			}
		}
		if ((hasLower) && (hasUpper) && (hasDigit)) {
			valid = true;
		}

		return valid;
	}

	public static boolean isAvailable(String s) {

		boolean available = true;
		UsersDao ud = new UsersDaoImpl();
		List<Users> users = ud.getUsers();

		for (Users u : users) {

			if (u.getUsername().equals(s)) {
				available = false;
				break;
			}
		}

		return available;
	}

	public static boolean validEmail(String s) {

		boolean a = false;
		char[] b = s.toCharArray();

		for (char c : b) {
			if (c == '@') {
				a = true;
				break;
			}
		}
		return a;
	}

}
