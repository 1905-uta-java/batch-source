import java.util.InputMismatchException;
import java.util.Scanner;

public class Helper {
	
	static Scanner kbd = new Scanner(System.in);
	
	public static int menu() {
		
		System.out.println("Welcome to Reserves Banking\n");
		System.out.println("Enter the number by the choice you'd like to make\n");

		System.out.println("1 - Log in (Existing user)");
		System.out.println("2 - Create an account");
		
		return getNum();
		
		
	}
	public static int getNum() {
		
		int input;
		try {
			input = kbd.nextInt();
		}
		
		catch (InputMismatchException e) {	
			kbd.next();
			System.out.println("Not a valid choice\n");
			return menu();
		}
		
		return input;
	}
	

}
