package com.revature.model;

import java.io.Serializable;

public class Checkings implements Serializable {

	private static final long serialVersionUID = 2659816491268936967L;
	private int checkingID;
	private int userID;
	private int accountNum;
	private int routNum;
	private double currBalance;
	
	public Checkings() {
		super();
		
	}
	
	public Checkings(int userID) {
		super();
		this.userID = userID;
		
	}
	
	public Checkings(int userID, double currBalcne) {
		super();
		this.userID = userID;
		this.currBalance = currBalcne;
	}
	
	public Checkings(int userID, int accountnumber) {
		super();
		this.userID = userID;
		this.accountNum = accountnumber;
	}

	public Checkings(int checkingID, int userID, int accountNum, int routNum, double currBalance) {
		super();
		this.checkingID = checkingID;
		this.userID = userID;
		this.accountNum = accountNum;
		this.routNum = routNum;
		this.currBalance = currBalance;
	}

	public int getCheckingID() {
		return checkingID;
	}

	public void setCheckingID(int checkingID) {
		this.checkingID = checkingID;
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public int getAccountNum() {
		return accountNum;
	}

	public void setAccountNum(int accountNum) {
		this.accountNum = accountNum;
	}

	public int getRoutNum() {
		return routNum;
	}

	public void setRoutNum(int routNum) {
		this.routNum = routNum;
	}

	public double getCurrBalance() {
		return currBalance;
	}

	public void setCurrBalance(double currBalance) {
		this.currBalance = currBalance;
	}

	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountNum;
		result = prime * result + checkingID;
		long temp;
		temp = Double.doubleToLongBits(currBalance);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + routNum;
		result = prime * result + userID;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Checkings other = (Checkings) obj;
		if (accountNum != other.accountNum)
			return false;
		if (checkingID != other.checkingID)
			return false;
		if (Double.doubleToLongBits(currBalance) != Double.doubleToLongBits(other.currBalance))
			return false;
		if (routNum != other.routNum)
			return false;
		if (userID != other.userID)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Checkings Account\n\n\tAccount Number = " + accountNum
				+ "\n\tRouting Number = " + routNum + "\n\tCurrent Balance = " + currBalance;
	}
	
	
	
	

}
