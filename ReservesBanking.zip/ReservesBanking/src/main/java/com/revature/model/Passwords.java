package com.revature.model;

import java.io.Serializable;

public class Passwords implements Serializable {

	private static final long serialVersionUID = 5954535715283850397L;
	
	private int passID;
	private int userID;
	private String password;
	
	
	public Passwords() {
		super();
	}
	
	public Passwords(int userID, String password) {
		super();
		this.userID = userID;
		this.password = password;
	}


	public Passwords(int passID, int userID, String password) {
		super();
		this.passID = passID;
		this.userID = userID;
		this.password = password;
	}


	public int getPassID() {
		return passID;
	}


	public void setPassID(int passID) {
		this.passID = passID;
	}


	public int getUserID() {
		return userID;
	}


	public void setUserID(int userID) {
		this.userID = userID;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + passID;
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + userID;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Passwords other = (Passwords) obj;
		if (passID != other.passID)
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (userID != other.userID)
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "Passwords [passID=" + passID + ", userID=" + userID + ", password=" + password + "]";
	}


}
