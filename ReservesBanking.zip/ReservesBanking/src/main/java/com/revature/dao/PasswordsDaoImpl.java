package com.revature.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.revature.model.Passwords;
import com.revature.model.Users;
import com.revature.util.ConnectionUtil;

public class PasswordsDaoImpl implements PasswordsDao {

	@Override
	public List<Passwords> getPasswords() {
		List<Passwords> passwords = new ArrayList<>();
		
		String sql = "SELECT * FROM PASSWORDS";
		
		try(Connection con = ConnectionUtil.getHardCodedConnection();
				Statement s = con.createStatement();
				ResultSet rs = s.executeQuery(sql))  {
		while(rs.next()) {
			Passwords p = new Passwords();
			
			int passID = rs.getInt("PW_ID");
			p.setPassID(passID);
			
			int userID = rs.getInt("USER_ID");
			p.setUserID(userID);
			
			String password = rs.getString("PW");
			p.setPassword(password);
			
			
			
			passwords.add(p);
		}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		return passwords;
	}

	@Override
	public Passwords getPasswordByID(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void createPassword(Passwords p) {
		int createdPassword = 0;
		String sql = "INSERT INTO PASSWORDS (USER_ID, PW) "
				+ "VALUES(?,?)";
		
		try(Connection con = ConnectionUtil.getHardCodedConnection();
				PreparedStatement ps = con.prepareStatement(sql)){
			
			
			ps.setInt(1, p.getUserID());
			ps.setString(2, p.getPassword());
	
			createdPassword = ps.executeUpdate();
		}
		
		catch(SQLException e) {
			e.printStackTrace();
		}
		//return createdPassword;
	}

	@Override
	public void updatePassword(Passwords u) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int deletePassword(int id) {
		// TODO Auto-generated method stub
		return 0;
	}

}
