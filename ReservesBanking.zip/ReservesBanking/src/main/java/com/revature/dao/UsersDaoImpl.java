package com.revature.dao;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.revature.model.Users;
import com.revature.util.ConnectionUtil;

public class UsersDaoImpl implements UsersDao {

	@Override
	public List<Users> getUsers() {
		List<Users> users = new ArrayList<>();
		
		String sql = "SELECT * FROM USERS";
		
		try(Connection con = ConnectionUtil.getHardCodedConnection();
				Statement s = con.createStatement();
				ResultSet rs = s.executeQuery(sql))  {
		while(rs.next()) {
			Users u = new Users();
			
			int userID = rs.getInt("USER_ID");
			u.setId(userID);
			
			String nameL = rs.getString("LAST_NAME");
			u.setLastName(nameL);
			
			String nameF = rs.getString("FIRST_NAME");
			u.setFirstName(nameF);
			
			String username = rs.getString("USERNAME");
			u.setUsername(username);
			
			String address = rs.getString("ADDRESS");
			u.setAddress(address);
			
			String state = rs.getString("STATE");
			u.setState(state);
			
			String city = rs.getString("CITY");
			u.setCity(city);
			
			String zipCode = rs.getString("ZIP_CODE");
			u.setZiipCode(zipCode);
			
			String phone = rs.getString("PHONE_NUMBER");
			u.setPhone(phone);
			
			String email = rs.getString("EMAIL");
			u.setEmail(email);
			
			users.add(u);
		}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		return users;
	}

	@Override
	public Users getUserById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void createUser(Users u) {
		int usersCreated = 0;
		String sql = "INSERT INTO USERS"
				+ "(first_name, last_name, username, address, state, city, zip_code, phone_number, email)"
				+ " VALUES(?,?,?,?,?,?,?,?,?)";
		
		try(Connection con = ConnectionUtil.getHardCodedConnection();
				PreparedStatement ps = con.prepareStatement(sql)){
			
			
			ps.setString(1, u.getLastName());
			ps.setString(2, u.getFirstName());
			ps.setString(3, u.getUsername());
			ps.setString(4, u.getAddress());
			ps.setString(5, u.getState());
			ps.setString(6, u.getCity());
			ps.setString(7, u.getZiipCode());
			ps.setString(8, u.getPhone());
			ps.setString(9, u.getEmail());
			
			usersCreated = ps.executeUpdate();
			
			
		}
		
		catch(SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public int updateUser(Users u) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteUser(int id) {
		// TODO Auto-generated method stub
		return 0;
	}

}
