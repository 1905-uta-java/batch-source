package com.revature.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.revature.model.Checkings;
import com.revature.model.Passwords;
import com.revature.util.ConnectionUtil;

public class CheckingsDaoImpl implements CheckingsDao{

	@Override
	public List<Checkings> getCheckingAccounts() {
		
		List<Checkings> checkings = new ArrayList<>();
		
		String sql = "SELECT * FROM CHECKING";
		
		try(Connection con = ConnectionUtil.getHardCodedConnection();
				Statement s = con.createStatement();
				ResultSet rs = s.executeQuery(sql))  {
		while(rs.next()) {
			Checkings c = new Checkings();
			
			int checkID = rs.getInt("CHECKING_ID");
			c.setCheckingID(checkID);
			
			int userID = rs.getInt("USER_ID");
			c.setUserID(userID);
			
			int account = rs.getInt("ACCOUNT_NUMBER");
			c.setAccountNum(account);
			
			int route = rs.getInt("ROUTING_NUMBER");
			c.setRoutNum(route);
			
			int cBalance = rs.getInt("CURRENT_BALANCE");
			c.setCurrBalance(cBalance);
			
			checkings.add(c);
		}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		return checkings;
	}

	@Override
	public Checkings getChecking(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void createChecking(Checkings c) {

		int createChecking = 0;
		String sql = "INSERT INTO CHECKING (USER_ID, ACCOUNT_NUMBER) "
				+ "VALUES(?, ?)";
		
		try(Connection con = ConnectionUtil.getHardCodedConnection();
				PreparedStatement ps = con.prepareStatement(sql)){
			
			
			ps.setInt(1, c.getUserID());
			ps.setInt(2, c.getAccountNum());
	
			createChecking = ps.executeUpdate();
		}
		
		catch(SQLException e) {
			e.printStackTrace();
		}
		//return createChecking;
		
	}

	@Override
	public void updateChecking(Checkings c) {
		
		int checkingsUpdated = 0;
		String sql = "UPDATE CHECKING "
				+ "SET CURRENT_BALANCE = ? "
				+ "WHERE USER_ID = ?";
		
		try (Connection con = ConnectionUtil.getHardCodedConnection();
				PreparedStatement ps = con.prepareStatement(sql)){
			
			//con.setAutoCommit(false);
			ps.setDouble(1, c.getCurrBalance());
			ps.setInt(2, c.getUserID());
			
			checkingsUpdated = ps.executeUpdate();
			//con.commit();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
	}

	@Override
	public int deleteChecking(int id) {
		// TODO Auto-generated method stub
		return 0;
	}

}
