package com.revature.dao;

import java.util.List;

import com.revature.model.Users;

public interface UsersDao {
	
	List<Users> getUsers();
	public Users getUserById(int id);
	public void createUser(Users u);
	public int updateUser(Users u);
	public int deleteUser(int id);

}
