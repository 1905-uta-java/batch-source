package com.revature.dao;

import java.util.List;

import com.revature.model.Passwords;

public interface PasswordsDao {
	
	List<Passwords> getPasswords();
	public Passwords getPasswordByID(int id);
	public void createPassword(Passwords p);
	public void updatePassword(Passwords p);
	public int deletePassword(int id);

}
