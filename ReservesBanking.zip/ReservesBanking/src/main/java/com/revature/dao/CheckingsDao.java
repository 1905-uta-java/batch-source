package com.revature.dao;

import java.util.List;

import com.revature.model.Checkings;


public interface CheckingsDao {
	
	List<Checkings> getCheckingAccounts();
	public Checkings getChecking(int id);
	public void createChecking(Checkings c);
	public void updateChecking(Checkings c);
	public int deleteChecking(int id);

}
