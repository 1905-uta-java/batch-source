import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class DriverTest {

	@Test
	public void validEmailTest() {
		boolean valid = Driver.validEmail("ben@gmail.com");
		assertEquals(true, valid);
	}
	
	@Test
	public void notValidEmailTest() {
		boolean valid = Driver.validEmail("bengmail.com");
		assertEquals(false, valid);
	}
	
	@Test
	public void isValidPassTest() {
		boolean valid = Driver.isValidPass("Benlow70");
		assertEquals(true, valid);
	}
	
	@Test
	public void noUpperInPassword() {
		boolean valid = Driver.isValidPass("benlee504");
		assertEquals(false, valid);
	}
	
	@Test
	public void noNumInPassword() {
		boolean valid = Driver.isValidPass("benleechow");
		assertEquals(false, valid);
	}
	
	@Test
	public void noIllegalChar() {
		boolean valid = Driver.noIllegalChar("benleechow");
		assertEquals(true, valid);
	}
	
	@Test
	public void hasIllegalChar() {
		boolean valid = Driver.noIllegalChar("ben*&leechow");
		assertEquals(false, valid);
	}
	
	@Test
	public void hasAllIllegalChars() {
		boolean valid = Driver.noIllegalChar("*&^^%%");
		assertEquals(false, valid);
	}
	
	@Test
	public void noIllegalCharAllCaps() {
		boolean valid = Driver.noIllegalChar("LASTNAMED");
		assertEquals(true, valid);
	}

}
